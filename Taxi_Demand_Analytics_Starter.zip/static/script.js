async function loadDashboard(){
  try{
    const response = await fetch("/api/analytics");
    if(!response.ok) throw new Error("Could not load analytics");
    const data = await response.json();

    document.getElementById("totalTrips").textContent = data.total_trips.toLocaleString();
    document.getElementById("avgFare").textContent = "$" + data.avg_fare.toFixed(2);
    document.getElementById("revenue").textContent = "$" + data.total_revenue.toLocaleString();
    document.getElementById("peakHour").textContent = String(data.peak_hour).padStart(2,"0") + ":00";

    new Chart(document.getElementById("hourChart"),{
      type:"line",
      data:{labels:data.hour_labels,datasets:[{label:"Trips",data:data.hour_values,
        borderColor:"#f2b900",backgroundColor:"rgba(255,201,40,.18)",fill:true,tension:.35,pointRadius:2}]},
      options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},
        scales:{y:{beginAtZero:true,grid:{color:"#f0f1f3"}},x:{grid:{display:false}}}}
    });
    new Chart(document.getElementById("pickupChart"),{
      type:"bar",
      data:{labels:data.pickup_labels,datasets:[{data:data.pickup_values,backgroundColor:"#ffc928",borderRadius:5}]},
      options:{indexAxis:"y",responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},
        scales:{x:{beginAtZero:true},y:{grid:{display:false}}}}
    });
    new Chart(document.getElementById("dropoffChart"),{
      type:"doughnut",
      data:{labels:data.dropoff_labels,datasets:[{data:data.dropoff_values,
        backgroundColor:["#ffc928","#303844","#f4a340","#8b96a5","#e8c85b","#c6ccd4"],borderWidth:0}]},
      options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:"bottom",labels:{boxWidth:10,font:{size:10}}}}}
    });
  }catch(error){
    console.error(error);
    document.querySelector(".welcome p").textContent="Unable to load data. Check that the Flask server is running.";
  }
}
loadDashboard();
