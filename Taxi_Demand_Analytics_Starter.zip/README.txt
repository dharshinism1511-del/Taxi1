TAXIPULSE - REAL-TIME TAXI DEMAND & MOBILITY ANALYTICS
=====================================================

This starter project contains:
- Frontend: HTML, CSS and JavaScript
- Backend: Python Flask
- Data analysis: Pandas
- Charts: Chart.js
- Dataset: taxi_data.csv (small sample for demonstration)

RUN ON A COMPUTER
1. Install Python 3.10 or newer.
2. Extract this ZIP folder.
3. Open a terminal inside the extracted folder.
4. Install packages:
      pip install -r requirements.txt
5. Start the website:
      python app.py
6. Open this address in your browser:
      http://127.0.0.1:5000

IMPORTANT
The included CSV is sample/demo data, not a live NYC taxi feed.
To use the official NYC Taxi dataset, replace taxi_data.csv while keeping
these column names:
pickup_datetime, pickup_location, dropoff_location, fare_amount

NEXT PROJECT STAGES
- Replace Pandas processing with PySpark for larger datasets.
- Add Kafka to stream simulated incoming taxi trips.
- Add SQL storage for processed trip records.
- Connect Power BI if required by the project guide.
