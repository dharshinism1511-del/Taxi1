from flask import Flask, render_template, jsonify
import pandas as pd
from pathlib import Path

app = Flask(__name__)
DATA_FILE = Path(__file__).parent / "taxi_data.csv"

def load_data():
    df = pd.read_csv(DATA_FILE)
    df["pickup_datetime"] = pd.to_datetime(df["pickup_datetime"], errors="coerce")
    df = df.dropna(subset=["pickup_datetime", "pickup_location", "dropoff_location"])
    return df

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/analytics")
def analytics():
    df = load_data()
    total_trips = int(len(df))
    avg_fare = round(float(df["fare_amount"].mean()), 2) if total_trips else 0
    total_revenue = round(float(df["fare_amount"].sum()), 2) if total_trips else 0

    hourly = (df.assign(hour=df["pickup_datetime"].dt.hour)
                .groupby("hour").size().reindex(range(24), fill_value=0))
    pickup_counts = df["pickup_location"].value_counts().head(6)
    dropoff_counts = df["dropoff_location"].value_counts().head(6)

    return jsonify({
        "total_trips": total_trips,
        "avg_fare": avg_fare,
        "total_revenue": total_revenue,
        "peak_hour": int(hourly.idxmax()) if total_trips else 0,
        "hour_labels": [f"{h:02d}:00" for h in hourly.index],
        "hour_values": [int(v) for v in hourly.values],
        "pickup_labels": pickup_counts.index.tolist(),
        "pickup_values": [int(v) for v in pickup_counts.values],
        "dropoff_labels": dropoff_counts.index.tolist(),
        "dropoff_values": [int(v) for v in dropoff_counts.values]
    })

if __name__ == "__main__":
    app.run(debug=True)
